<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class pipeline extends Model
{
    protected $table = 'pipelines';
//    protected $fillable = ['name'];
}
