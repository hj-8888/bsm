<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="kor">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title>Document</title>
</head>
<body>
<?php echo $__env->make('Layout.Sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="min-h-screen" style="margin-left: 5%; margin-right: 5%;width: 77%;float:right">
    <h1>
        메인
    </h1>
    <h2>
        주간 변경사항
    </h2>
    <h3>
        견적리스트
    </h3>
    <table>
        <thead>
        <tr>
            <th>날짜</th>
            <th>견적번호</th>
            <th>장부/고객</th>
            <th>유형</th>
            <th>사업자(주민)등록번호</th>
            <th>견적금액</th>
            <th>활인율</th>
            <th>종류</th>
            <th>수주</th>
            <th>조회</th>
        </tr>
        </thead>
        <tbody>
        <tr>
        <?php $__currentLoopData = $Estimates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Estimate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($Estimate->create_date); ?></td>
                <td><?php echo e($Estimate->id); ?></td>
                <td><?php echo e($Estimate->client); ?></td>
                <td><?php echo e($Estimate->type); ?></td>
                <td><?php echo e($Estimate->contact_id); ?></td>
                <td><?php echo e($Estimate->amount); ?></td>
                <td><?php echo e($Estimate->discount_rate); ?></td>
                <td><?php echo e($Estimate->general); ?></td>
                <td><?php echo e($Estimate->order_state); ?></td>
                <td><button id="<?php echo e($Estimate->id); ?>" type="button" style="width: 100%"
                            value="<?php echo e($Estimate->id); ?>" onclick="javascript:clickTrEvent(this)">조회</button></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        </tbody>
    </table>
    <h3>
        사업관리 리스트
    </h3>
    <table>
        <thead>
        <tr>
            <th>번호</th>
            <th>거래처</th>
            <th>고객사</th>
            <th>건명</th>
            <th>예상 매출</th>
            <th>예상 매입</th>
            <th>예상 매출이익</th>
            <th>발행시기</th>
            <th>최종컨택일</th>
            <th>진행률</th>
            <th>담당자</th>
            <th>진행사항</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $business; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->contact->company_name); ?></td>
                <td><?php echo e($item->client); ?></td>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->expected_sales); ?></td>
                <td><?php echo e($item->expected_purchase); ?></td>
                <td><?php echo e($item->expected_sales_profit); ?></td>
                <td><?php echo e($item->expected_issue_month); ?></td>
                <td><?php echo e($item->progress_rate); ?></td>
                <td><?php echo e($item->sales_person); ?></td>
                <td><?php echo e($item->progress); ?></td>
                <td></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <h3>
        수주 품의 리스트
    </h3>
    <table>
        <thead>
        <tr>
            <th>계약번호</th>
            <th>거래처</th>
            <th>담당자</th>
            <th>담당부서</th>
            <th>작성일자</th>
            <th>수정일자</th>
            <th>조회</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->contract_number); ?></td>
                <td><?php echo e($item->customer_name); ?></td>
                <td><?php echo e($item->manager); ?></td>
                <td><?php echo e($item->department); ?></td>
                <td><?php echo e($item->created_at); ?></td>
                <td><?php echo e($item->updated_at); ?></td>
                <td>
                    <a href="/OrderBook/<?php echo e($item->contract_number); ?>"><input id="firstRow" type="button" style="width: 100%" type="button" value="조회"></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</body>
</html>

<style type="text/css">
    a {
        color: inherit;
        text-decoration: inherit
    }

    table {
        width: 100%;
        border: 1px solid black
    }

    thead {
        background-color: #eeeeee
    }


</style>
<?php /**PATH C:\Users\Administrator\Documents\GitHub\bsm\resources\views/main.blade.php ENDPATH**/ ?>